using UnityEngine;

namespace Consumable
{
    public enum ConsumableType
    {
        VaccinesRefill,
        RestoreHealth,
        Mask
    }
}

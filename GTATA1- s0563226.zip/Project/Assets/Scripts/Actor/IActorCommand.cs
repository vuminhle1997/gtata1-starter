﻿namespace Actor
{
    /// <summary>
    /// Interface with dummy method
    /// </summary>
    public interface IActorCommand
    {
        void Execute();
    }
}
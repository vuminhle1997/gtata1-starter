﻿namespace Actor
{
    /// <summary>
    /// later exercise
    /// </summary>
    public interface IUnit
    {
        
    }
}
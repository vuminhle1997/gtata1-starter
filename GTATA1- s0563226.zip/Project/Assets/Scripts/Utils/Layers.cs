﻿namespace Utils
{
    public static class Layers
    {
        public const int Enemy = 9;
        public const int Obstacle = 10;
        public const int Ground = 11;
    }
}